<?php
include 'config.php';

// --- Search handling ---
$search = isset($_GET['search']) ? $_GET['search'] : '';

$sql = "SELECT * FROM entries 
        WHERE name LIKE '%$search%' OR email LIKE '%$search%' 
        ORDER BY id DESC";

$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>View Entries - My Project</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    th.sortable { cursor: pointer; }
    th.sortable::after { content: ''; float: right; margin-left: 5px; }
    th.sortable.asc::after { content: '↑'; }
    th.sortable.desc::after { content: '↓'; }
  </style>
</head>
<body>
<div class="container mt-5">

  <h2 class="mb-4">ALL ENTRIES</h2>

  <!-- Search Form -->
  <form method="GET" class="mb-3">
      <input type="text" name="search" class="form-control" 
             placeholder="Search by Name or Email"
             value="<?php if(isset($_GET['search'])) echo $_GET['search']; ?>">
  </form>

  <!-- Responsive Table -->
  <div class="table-responsive">
    <table class="table table-bordered table-striped table-hover" id="entriesTable">
      <thead class="table-dark">
        <tr>
          <th class="sortable" onclick="sortTable(0)">ID</th>
          <th class="sortable" onclick="sortTable(1)">Name</th>
          <th class="sortable" onclick="sortTable(2)">Email</th>
          <th class="sortable" onclick="sortTable(3)">Phone</th>
          <th class="sortable" onclick="sortTable(4)">Created At</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
      <?php 
      if ($result->num_rows > 0) {
          while($row = $result->fetch_assoc()) {
              ?>
              <tr>
                <td><?php echo $row['id']; ?></td>
                <td><?php echo $row['name']; ?></td>
                <td><?php echo $row['email']; ?></td>
                <td><?php echo $row['phone']; ?></td>
                <td><?php echo $row['created_at']; ?></td>
                <td>
                  <a href="update.php?id=<?php echo $row['id']; ?>" class="btn btn-sm btn-primary">Edit</a>

                  <!-- Delete Button triggers modal -->
                  <button type="button" class="btn btn-sm btn-danger" 
                          data-bs-toggle="modal" data-bs-target="#deleteModal<?php echo $row['id']; ?>">
                    Delete
                  </button>

                  <!-- Delete Modal -->
                  <div class="modal fade" id="deleteModal<?php echo $row['id']; ?>" tabindex="-1" aria-hidden="true">
                    <div class="modal-dialog">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title">Confirm Delete</h5>
                          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                          Are you sure you want to delete <strong><?php echo $row['name']; ?></strong>?
                        </div>
                        <div class="modal-footer">
                          <a href="delete.php?id=<?php echo $row['id']; ?>" class="btn btn-danger">Yes, Delete</a>
                          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        </div>
                      </div>
                    </div>
                  </div>

                </td>
              </tr>
              <?php
          }
      } else {
          echo "<tr><td colspan='6' class='text-center'>No entries found</td></tr>";
      }
      ?>
      </tbody>
    </table>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
let currentSortCol = -1;
let currentSortDir = "asc";

function sortTable(n) {
  const table = document.getElementById("entriesTable");
  const tbody = table.tBodies[0];
  const rowsArray = Array.from(tbody.rows);

  // Determine sort direction
  let dir = "asc";
  if(currentSortCol === n){
      dir = currentSortDir === "asc" ? "desc" : "asc";
  }
  currentSortCol = n;
  currentSortDir = dir;

  // Reset previous column arrows
  Array.from(table.tHead.rows[0].cells).forEach((th, index) => {
    th.classList.remove("asc","desc");
    if(index === n) th.classList.add(dir);
  });

  rowsArray.sort((rowA, rowB) => {
    let x = rowA.cells[n].innerText.trim();
    let y = rowB.cells[n].innerText.trim();

    let xValue, yValue;

    // Detect date
    if(!isNaN(Date.parse(x)) && !isNaN(Date.parse(y))){
      xValue = new Date(x);
      yValue = new Date(y);
    }
    // Detect number
    else if(!isNaN(parseFloat(x)) && !isNaN(parseFloat(y))){
      xValue = parseFloat(x);
      yValue = parseFloat(y);
    }
    // Text
    else{
      xValue = x.toLowerCase();
      yValue = y.toLowerCase();
    }

    if(xValue < yValue) return dir === "asc" ? -1 : 1;
    if(xValue > yValue) return dir === "asc" ? 1 : -1;
    return 0;
  });

  // Re-append rows in sorted order
  rowsArray.forEach(row => tbody.appendChild(row));
}
</script>

</body>
</html>
