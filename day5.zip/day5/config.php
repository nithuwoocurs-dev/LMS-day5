<?php
// config.php
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

$servername = 'localhost';
$username   = 'root';
$password   = '';               // XAMPP default is empty; MAMP default is 'root'
$database   = 'lms_project_db';

$conn = new mysqli($servername, $username, $password, $database);
$conn->set_charset('utf8mb4');
