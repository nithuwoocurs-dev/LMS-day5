<?php
require __DIR__ . '/config.php';

// Optional: tiny query to prove the connection works.
$conn->query("SELECT 1");

echo 'Database Connected!';
