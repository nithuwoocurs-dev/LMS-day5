<?php
include 'config.php';

$warning = ""; 
$name = $email = $phone = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name  = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];

    // Validation
    if (empty($name) || empty($email) || empty($phone)) {
        $warning = "All fields are required!";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $warning = "Invalid email format!";
    } elseif (!is_numeric($phone) || strlen($phone) != 10) {
        $warning = "Phone must be 10 digits!";
    } else {
        // Check if email already exists
        $check = $conn->query("SELECT * FROM entries WHERE email='$email'");
        if ($check->num_rows > 0) {
            $warning = "⚠️ This email already exists!";
        } else {
            $sql = "INSERT INTO entries (name, email, phone) VALUES ('$name','$email','$phone')";
            if ($conn->query($sql) === TRUE) {
                header("Location: form.php?ok=1");
                exit();
            } else {
                $warning = "Error: " . $conn->error;
            }
        }
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Form - Library Management System</title>
  <link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"
    rel="stylesheet"
  />
  <link rel="stylesheet" href="form.css" />
</head>
<body class="bg-light">
  <div class="container mt-5">

    <!-- Success Message -->
    <?php if (isset($_GET['ok']) && $_GET['ok'] == '1'): ?>
      <div class="alert alert-success" role="alert">
        ✅ Entry added successfully!
      </div>
    <?php endif; ?>

    <!-- Warning Message -->
    <?php if (!empty($warning)): ?>
      <div class="alert alert-warning" role="alert">
        <?php echo $warning; ?>
      </div>
    <?php endif; ?>

    <h2 class="mb-4">Add Entry</h2>

    <form method="POST" action="form.php" onsubmit="return validateForm()">
      <div class="mb-3">
        <label class="form-label">Name</label>
        <!-- Auto-uppercase + real-time validation -->
        <input type="text" id="name" name="name" class="form-control"
               placeholder="Enter Name"
               value="<?php echo htmlspecialchars($name ?? ''); ?>"
               oninput="this.value=this.value.toUpperCase()">
      </div>
      <div class="mb-3">
        <label class="form-label">Email</label>
        <input type="email" id="email" name="email" class="form-control"
               placeholder="Enter Email"
               value="<?php echo htmlspecialchars($email ?? ''); ?>">
      </div>
      <div class="mb-3">
        <label class="form-label">Phone</label>
        <!-- Phone mask (numbers only) -->
        <input type="text" id="phone" name="phone" class="form-control"
               placeholder="Enter Phone"
               value="<?php echo htmlspecialchars($phone ?? ''); ?>"
               oninput="this.value=this.value.replace(/[^0-9]/g,'')">
      </div>
      <button type="submit" class="btn btn-success">Submit</button>
      <button type="reset" class="btn btn-secondary">Clear Form</button>
    </form>
  </div>

  <script>
    // Client-side validation
    function validateForm() {
      let name = document.getElementById("name").value;
      let email = document.getElementById("email").value;
      let phone = document.getElementById("phone").value;

      if (name == "" || email == "" || phone == "") {
        alert("All fields are required!");
        return false;
      }
      if (!email.includes("@")) {
        alert("Invalid email format!");
        return false;
      }
      if (phone.length !== 10 || isNaN(phone)) {
        alert("Phone must be 10 digits!");
        return false;
      }
      return true;
    }

    // Real-time validation for Name
    document.getElementById("name").addEventListener("input", function() {
      let name = this.value;
      if (name.length < 3) {
        this.style.borderColor = "red";
      } else {
        this.style.borderColor = "green";
      }
    });

    // Real-time validation for Phone
    document.getElementById("phone").addEventListener("input", function() {
      if (this.value.length !== 10) {
        this.style.borderColor = "red";
      } else {
        this.style.borderColor = "green";
      }
    });

    // Clear URL params after reload
    if (window.history.replaceState) {
        window.history.replaceState(null, null, window.location.pathname);
    }
  </script>
</body>
</html>
